package reldir

import "github.com/mgutz/logxi/v1"

// Foo returns error
func Foo() {
	log.Error("Oh bar!")
}
